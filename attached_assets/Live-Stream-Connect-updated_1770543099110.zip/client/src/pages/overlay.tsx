import { useEffect, useState, useRef } from "react";
import type { BattleState } from "@shared/schema";

export default function Overlay() {
  const [state, setState] = useState<BattleState>({
    isConnected: false,
    isBattleActive: false,
    participantA: null,
    participantB: null,
    roundWinner: null,
    username: "",
  });
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectRef = useRef<NodeJS.Timeout>();

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const username = params.get("username")?.replace("@", "") || "";
    if (!username) return;

    const connect = () => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const ws = new WebSocket(`${protocol}//${window.location.host}/ws?username=${username}&role=overlay`);
      wsRef.current = ws;

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          if (msg.type === "battle_state") {
            setState(msg.payload);
          }
        } catch {}
      };

      ws.onclose = () => {
        reconnectRef.current = setTimeout(connect, 2000);
      };

      ws.onerror = () => ws.close();
    };

    connect();
    return () => {
      wsRef.current?.close();
      clearTimeout(reconnectRef.current);
    };
  }, []);

  const { participantA, participantB, isBattleActive, roundWinner } = state;

  if (!isBattleActive || !participantA || !participantB) {
    return (
      <div className="overlay-root">
        <div className="waiting-badge">
          <span className="waiting-dot" />
          Aguardando batalha...
        </div>
        <style>{overlayStyles}</style>
      </div>
    );
  }

  const renderHearts = (count: number) => {
    const hearts = [];
    for (let i = 0; i < 5; i++) {
      hearts.push(
        <svg
          key={i}
          className={`heart-icon ${i < count ? "heart-active" : "heart-empty"}`}
          viewBox="0 0 24 24"
          fill={i < count ? "currentColor" : "none"}
          stroke="currentColor"
          strokeWidth="2"
        >
          <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
        </svg>
      );
    }
    return hearts;
  };

  const aWonRound = roundWinner === participantA.nickname;
  const bWonRound = roundWinner === participantB.nickname;

  const proxyUrl = (url: string) => {
    if (!url) return "";
    return `/api/avatar-proxy?url=${encodeURIComponent(url)}`;
  };

  const fallbackA = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Crect width='80' height='80' fill='%23333'/%3E%3Ctext x='50%25' y='50%25' text-anchor='middle' dy='.3em' fill='white' font-size='30'%3EA%3C/text%3E%3C/svg%3E";
  const fallbackB = "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Crect width='80' height='80' fill='%23333'/%3E%3Ctext x='50%25' y='50%25' text-anchor='middle' dy='.3em' fill='white' font-size='30'%3EB%3C/text%3E%3C/svg%3E";

  const avatarA = participantA.profilePictureUrl ? proxyUrl(participantA.profilePictureUrl) : fallbackA;
  const avatarB = participantB.profilePictureUrl ? proxyUrl(participantB.profilePictureUrl) : fallbackB;

  return (
    <div className="overlay-root">
      <div id="overlay">
        <div className={`part side-a ${aWonRound ? "winning" : ""}`}>
          <img
            src={avatarA}
            alt={participantA.nickname}
            className="avatar"
            onError={(e) => { (e.target as HTMLImageElement).src = fallbackA; }}
          />
          <div className="info">
            <div className="name" data-testid="text-name-a">{participantA.nickname}</div>
            <div className="hearts-row">
              {renderHearts(participantA.hearts)}
            </div>
          </div>
          <div className="score-block">
            <div className="score" data-testid="text-score-a">
              {participantA.points.toLocaleString()}
            </div>
            {aWonRound && <div className="winning-tag">WIN</div>}
          </div>
        </div>

        <div className="vs-divider">
          <span className="vs-text">VS</span>
        </div>

        <div className={`part side-b ${bWonRound ? "winning" : ""}`}>
          <div className="score-block">
            <div className="score" data-testid="text-score-b">
              {participantB.points.toLocaleString()}
            </div>
            {bWonRound && <div className="winning-tag">WIN</div>}
          </div>
          <div className="info info-right">
            <div className="name" data-testid="text-name-b">{participantB.nickname}</div>
            <div className="hearts-row hearts-right">
              {renderHearts(participantB.hearts)}
            </div>
          </div>
          <img
            src={avatarB}
            alt={participantB.nickname}
            className="avatar"
            onError={(e) => { (e.target as HTMLImageElement).src = fallbackB; }}
          />
        </div>
      </div>
      <style>{overlayStyles}</style>
    </div>
  );
}

const overlayStyles = `
  * { margin: 0; padding: 0; box-sizing: border-box; }

  body, html {
    background: transparent !important;
    overflow: hidden;
  }

  .overlay-root {
    width: 100vw;
    height: 100vh;
    display: flex;
    align-items: flex-start;
    justify-content: center;
    padding-top: 20px;
    font-family: 'Inter', 'Segoe UI', Arial, sans-serif;
  }

  .waiting-badge {
    display: flex;
    align-items: center;
    gap: 8px;
    background: rgba(0, 0, 0, 0.7);
    color: #aaa;
    padding: 10px 20px;
    border-radius: 20px;
    font-size: 14px;
    backdrop-filter: blur(10px);
  }

  .waiting-dot {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #ff3b5c;
    animation: pulse 1.5s infinite;
  }

  @keyframes pulse {
    0%, 100% { opacity: 1; transform: scale(1); }
    50% { opacity: 0.4; transform: scale(0.8); }
  }

  #overlay {
    width: 900px;
    height: 180px;
    background: rgba(0, 0, 0, 0.85);
    border-radius: 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20px;
    color: white;
    position: relative;
  }

  .part {
    display: flex;
    align-items: center;
    gap: 12px;
    flex: 1;
  }

  .side-a {
    justify-content: flex-start;
  }

  .side-b {
    justify-content: flex-end;
  }

  .avatar {
    width: 70px;
    height: 70px;
    border-radius: 50%;
    border: 3px solid rgba(255, 255, 255, 0.3);
    background: #333;
    object-fit: cover;
    flex-shrink: 0;
  }

  .side-a .avatar {
    border-color: rgba(59, 130, 246, 0.7);
  }

  .side-b .avatar {
    border-color: rgba(239, 68, 68, 0.7);
  }

  .part.winning .avatar {
    border-color: rgba(251, 191, 36, 0.8);
    box-shadow: 0 0 12px rgba(251, 191, 36, 0.3);
  }

  .info {
    display: flex;
    flex-direction: column;
    gap: 6px;
    min-width: 0;
  }

  .info-right {
    text-align: right;
    align-items: flex-end;
  }

  .name {
    color: #fff;
    font-size: 15px;
    font-weight: 700;
    max-width: 160px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }

  .hearts-row {
    display: flex;
    gap: 3px;
  }

  .hearts-right {
    justify-content: flex-end;
  }

  .heart-icon {
    width: 16px;
    height: 16px;
    transition: all 0.3s ease;
  }

  .heart-active {
    color: #ef4444;
    filter: drop-shadow(0 0 3px rgba(239, 68, 68, 0.5));
  }

  .heart-empty {
    color: rgba(255, 255, 255, 0.15);
  }

  .score-block {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 4px;
    flex-shrink: 0;
  }

  .score {
    font-size: 28px;
    font-weight: 900;
    color: #fff;
    font-variant-numeric: tabular-nums;
    line-height: 1;
    min-width: 60px;
    text-align: center;
  }

  .winning-tag {
    background: linear-gradient(135deg, #f59e0b, #d97706);
    color: #000;
    font-size: 9px;
    font-weight: 800;
    padding: 2px 10px;
    border-radius: 8px;
    letter-spacing: 1px;
    animation: winPop 0.4s ease-out;
  }

  @keyframes winPop {
    0% { transform: scale(0); opacity: 0; }
    60% { transform: scale(1.2); opacity: 1; }
    100% { transform: scale(1); opacity: 1; }
  }

  .vs-divider {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    padding: 0 8px;
  }

  .vs-text {
    background: linear-gradient(135deg, #ff3b5c, #ff6b3b);
    color: #fff;
    font-size: 18px;
    font-weight: 900;
    padding: 10px 16px;
    border-radius: 14px;
    letter-spacing: 2px;
    text-shadow: 0 1px 2px rgba(0,0,0,0.3);
  }

  @keyframes scoreFlash {
    0% { transform: scale(1); }
    50% { transform: scale(1.1); }
    100% { transform: scale(1); }
  

  // === USER CONFIG SYNC (auto-applied) ===
  useEffect(() => {
    const applyConfig = () => {
      const overlay = document.getElementById("overlay");
      if (!overlay) return;

      // layout
      const layout = localStorage.getItem("overlayLayout") || "horizontal";
      overlay.classList.remove("layout-horizontal","layout-vertical","layout-stacked");
      overlay.classList.add("layout-" + layout);

      // transparent background
      const transparent = localStorage.getItem("overlayTransparent") === "true";
      if (transparent) {
        document.body.classList.add("overlay-transparent");
      } else {
        document.body.classList.remove("overlay-transparent");
      }

      // heart color
      const color = localStorage.getItem("heartColor") || "#ff0000";
      document.documentElement.style.setProperty("--heart-color", color);

      // defeated effect: if no hearts, add class
      const leftHearts = document.getElementById("coracoesA");
      const rightHearts = document.getElementById("coracoesB");
      const leftBox = document.querySelector(".participant.left");
      const rightBox = document.querySelector(".participant.right");

      if (leftBox && leftHearts) {
        if ((leftHearts.textContent || "").trim().length === 0) {
          leftBox.classList.add("defeated");
        } else {
          leftBox.classList.remove("defeated");
        }
      }

      if (rightBox && rightHearts) {
        if ((rightHearts.textContent || "").trim().length === 0) {
          rightBox.classList.add("defeated");
        } else {
          rightBox.classList.remove("defeated");
        }
      }
    };

    applyConfig();
    window.addEventListener("overlay-config", applyConfig);
    const timer = setInterval(applyConfig, 1500);
    return () => {
      window.removeEventListener("overlay-config", applyConfig);
      clearInterval(timer);
    };
  }, []);

}
`;
